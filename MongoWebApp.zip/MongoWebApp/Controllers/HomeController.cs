﻿using Microsoft.AspNetCore.Mvc;
using MongoWebApp.BusinessLayer;
using MongoWebApp.Models;
using System.Diagnostics;

namespace MongoWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private ICityService _cityService;
        private IProvinceService _provinceService;

        public HomeController(ILogger<HomeController> logger, ICityService cityService, IProvinceService provinceService)
        {
            _logger = logger;
            _cityService = cityService;
            _provinceService = provinceService;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _provinceService.GetProvincesAsync());
        }

        [Route("cities/{province}")]
        public async Task<IActionResult> Cities([FromRoute] string province, [FromQuery] int page = 0, [FromQuery] int size = 50)
        {
            return View(await _cityService.GetCitiesAsync(province, page, size));
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
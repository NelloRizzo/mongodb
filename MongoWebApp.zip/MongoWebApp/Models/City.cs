﻿using MongoDB.Bson.Serialization.Attributes;

namespace MongoWebApp.Models
{
    public class City
    {
        [BsonId]
        [BsonElement("_id")]
        public int? Id { get; set; }
        [BsonElement("denominazione")]
        public string? Name { get; set; }
        [BsonElement("catastale")]
        public string? Cadastral { get; set; }
        [BsonElement("capoluogo")]
        public bool? IsCapital { get; set; }
        [BsonElement("sigla")]
        public string? Acronym { get; set; }
    }
}

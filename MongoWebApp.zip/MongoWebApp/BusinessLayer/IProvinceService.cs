﻿using MongoWebApp.Models;

namespace MongoWebApp.BusinessLayer
{
    public interface IProvinceService
    {
        Task<IList<Province>> GetProvincesAsync();
    }
}

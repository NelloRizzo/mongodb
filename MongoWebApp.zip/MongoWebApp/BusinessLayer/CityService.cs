﻿using MongoDB.Driver;
using MongoWebApp.DataLayer;
using MongoWebApp.Models;

namespace MongoWebApp.BusinessLayer
{
    public class CityService : ICityService
    {
        protected readonly ICityDao _cityDao;
        public CityService(ICityDao cityDao) { _cityDao = cityDao; }
        public async Task<IList<City>> GetCitiesAsync(string acronym, int page, int size)
            => await (await _cityDao.GetAllAsync(acronym, page, size)).ToListAsync();
    }
}

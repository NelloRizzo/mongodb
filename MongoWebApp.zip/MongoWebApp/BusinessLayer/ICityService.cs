﻿using MongoWebApp.Models;

namespace MongoWebApp.BusinessLayer
{
    public interface ICityService
    {
        Task<IList<City>> GetCitiesAsync(string acronym, int page, int size);
    }
}

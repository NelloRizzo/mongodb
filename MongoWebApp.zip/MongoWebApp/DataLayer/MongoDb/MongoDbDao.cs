﻿using System.Text;

namespace MongoWebApp.DataLayer.MongoDb
{
    public abstract class MongoDbDao<T> : IDao<T>
    {
        protected readonly MongoDB.Driver.MongoClient _client;

        public MongoDbDao(IConfiguration config)
        {
            var pwd = Encoding.UTF8.GetString(Convert.FromBase64String("cjF6ejAubmVsbDAubW9uZzA="));
            var connectionString = string.Format(config.GetConnectionString("mongo") ?? throw new Exception("Invalid connection string"), pwd);
            _client = new MongoDB.Driver.MongoClient(connectionString);
        }

        public abstract Task<T> CreateAsync(T entity);
        public abstract Task<T> DeleteAsync(string id);
        public abstract Task<T> GetAsync(string id);
        public abstract Task<T> UpdateAsync(string id, T entity);
    }
}

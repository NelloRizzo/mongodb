﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using MongoDB.Driver;
using MongoWebApp.Models;
using System.Drawing;

namespace MongoWebApp.DataLayer.MongoDb
{
    public class ProvinceDao : MongoDbDao<Province>, IProvinceDao
    {
        private readonly string dbName = "corso";
        private readonly string collectionName = "provinces";
        private readonly IMongoCollection<Province> _collection;
        public ProvinceDao(IConfiguration config) : base(config)
        {
            _collection = _client.GetDatabase(dbName)?.GetCollection<Province>(collectionName) ?? throw new Exception("Database not found");
        }

        public override Task<Province> CreateAsync(Province entity)
        {
            throw new NotImplementedException();
        }

        public override Task<Province> DeleteAsync(string id)
        {
            throw new NotImplementedException();
        }

        public override Task<Province> GetAsync(string id)
        {
            throw new NotImplementedException();
        }

        public async Task<IAsyncCursor<Province>> GetAllAsync()
            => await _collection.Aggregate()
                .Sort(new SortDefinitionBuilder<Province>().Ascending(c => c.Name))
                .ToCursorAsync()
            ;

        public override Task<Province> UpdateAsync(string id, Province entity)
        {
            throw new NotImplementedException();
        }
    }
}

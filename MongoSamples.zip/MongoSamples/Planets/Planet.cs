﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using nr.Describable;

namespace Planets
{
    public class Planet : JSONDescribable
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("_id")]
        public string? Id { get; set; }
        [BsonElement("hasRings")]
        [Name("Rings")]
        public bool HasRings { get; set; }
        [BsonElement("mainAtmosphere")]
        public IList<string> MainAtmosphere { get; set; } = new List<string>();
        [BsonElement("name")]
        public string? Name { get; set; }
        [BsonElement("orderFromSun")]
        public int? OrderFromSun { get; set; }
        [BsonElement("surfaceTemperatureC")]
        public SurfaceTemperature? SurfaceTemperature { get; set; }
    }
}

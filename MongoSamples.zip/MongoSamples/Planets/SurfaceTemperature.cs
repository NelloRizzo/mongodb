﻿using MongoDB.Bson.Serialization.Attributes;
using nr.Describable;

namespace Planets
{
    public enum MeasureUnit
    {
        Celsius, Fahrenheit
    }
    public class SurfaceTemperature : JSONDescribable
    {
        [BsonElement("max")]
        public double? Max { get; set; }
        [BsonElement("min")]
        public double? Min { get; set; }
        [BsonElement("mean")]
        public double? Mean { get; set; }
        [Ignore]
        public MeasureUnit MeasureUnit { get; set; } = MeasureUnit.Celsius;
    }

    public static class SurfaceTemperatureHelpers
    {
        public static SurfaceTemperature ToFahrenheit(this SurfaceTemperature temperature)
        {
            if (temperature.MeasureUnit == MeasureUnit.Fahrenheit) return temperature;
            return new SurfaceTemperature
            {
                Max = temperature.Max * 33.8,
                Min = temperature.Min * 33.8,
                Mean = temperature.Mean * 33.8,
                MeasureUnit = MeasureUnit.Fahrenheit
            };
        }
        public static SurfaceTemperature ToCelsius(this SurfaceTemperature temperature)
        {
            if (temperature.MeasureUnit == MeasureUnit.Celsius) return temperature;
            return new SurfaceTemperature
            {
                Max = temperature.Max / 33.8,
                Min = temperature.Min / 33.8,
                Mean = temperature.Mean / 33.8,
                MeasureUnit = MeasureUnit.Celsius
            };
        }
    }
}
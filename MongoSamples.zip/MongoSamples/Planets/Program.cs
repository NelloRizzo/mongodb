﻿using MongoDB.Driver;
using Planets;
using System.Text;

var pwd = Encoding.UTF8.GetString(Convert.FromBase64String("cjF6ejAubmVsbDAubW9uZzA="));
var connectionString = $"mongodb+srv://ennerre:{pwd}@cluster0.lh3sthm.mongodb.net/";
var dbName = "sample_guides";
var collectionName = "planets";

var client = new MongoClient(connectionString);
var database = client.GetDatabase(dbName);
var collection = database.GetCollection<Planet>(collectionName);

await collection.AsQueryable().ForEachAsync(Console.WriteLine);



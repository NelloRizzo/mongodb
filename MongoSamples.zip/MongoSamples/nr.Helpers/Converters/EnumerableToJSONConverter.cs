﻿namespace nr.Helpers.Converters
{
    public class EnumerableToJSONConverter : ITypeToJSONConverter
    {
        protected List<ITypeToJSONConverter> _converters;
        public EnumerableToJSONConverter(List<ITypeToJSONConverter> converters)
        {
            _converters = converters;
        }
        public bool CanConvert(object? type) => type is IEnumerable<object>;

        public string Convert(object? value)
        {
            if (value == null) return "null";
            return $"[{string.Join(',',
               (value as IEnumerable<object>)!.AsQueryable().Select(v =>
                     _converters.FirstOrDefault(c => c.CanConvert(v)) != null ? _converters.FirstOrDefault(c => c.CanConvert(v))!.Convert(v) : v.ToString()
            ))}]";
        }
    }
}

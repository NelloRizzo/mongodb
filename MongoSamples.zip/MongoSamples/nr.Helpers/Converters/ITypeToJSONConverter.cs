﻿namespace nr.Helpers.Converters
{
    public interface ITypeToJSONConverter
    {
        bool CanConvert(object? type);
        string Convert(object? value);
    }
}

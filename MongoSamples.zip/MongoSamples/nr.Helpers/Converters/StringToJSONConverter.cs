﻿namespace nr.Helpers.Converters
{
    public class StringToJSONConverter : ITypeToJSONConverter
    {
        public bool CanConvert(object? type) => type is string;
        public string Convert(object? value) => $"\"{value}\"";
    }
}

﻿using nr.Helpers.Converters;
using System.Reflection;

namespace nr.Describable
{
    public class JSONDescribable
    {
        [AttributeUsage(AttributeTargets.Property)]
        public class IgnoreAttribute : Attribute
        {
            public bool Ignore { get; private set; }
            public IgnoreAttribute(bool ignore = true) { Ignore = ignore; }
        }

        [AttributeUsage(AttributeTargets.Property)]
        public class NameAttribute : Attribute
        {
            public string? Name { get; private set; }
            public NameAttribute(string name) { Name = name; }
        }

        protected readonly List<ITypeToJSONConverter> converters = new();

        public JSONDescribable()
        {
            converters.AddRange(new ITypeToJSONConverter[]{
                new StringToJSONConverter(),
                new EnumerableToJSONConverter(converters),
                });
        }
        protected virtual string OutName(string name) => $"\"{char.ToLower(name[0])}{name[1..]}\"";
        protected virtual string OutValue(object? value)
        {
            if (value == null) return "null";
            string converted = converters.FirstOrDefault(c => c.CanConvert(value))?.Convert(value)!;
            return converted ?? value!.ToString()!;
        }
        public override string ToString()
        => $"{{{string.Join(", ",
            GetType().GetProperties()
            .Where(p => p.GetCustomAttribute<IgnoreAttribute>() == null || !p.GetCustomAttribute<IgnoreAttribute>()!.Ignore)
            .Select(p => new { Property = p, Name = (p.GetCustomAttribute<NameAttribute>())?.Name ?? p.Name })
            .Select(r => $"{OutName(r.Name)}: {OutValue(r.Property.GetValue(this))}"))}}}";
    }
}
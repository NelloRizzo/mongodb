﻿using MongoDB.Driver;
using System.Text;
using TimeSeries;

var pwd = Encoding.UTF8.GetString(Convert.FromBase64String("cjF6ejAubmVsbDAubW9uZzA="));
var connectionString = $"mongodb+srv://ennerre:{pwd}@cluster0.lh3sthm.mongodb.net/";
var dbName = "corso";
var collectionName = "weather";

var client = new MongoClient(connectionString);
var db = client.GetDatabase(dbName);
await db.CreateCollectionAsync(collectionName,
    new CreateCollectionOptions { TimeSeriesOptions = new TimeSeriesOptions("registration_time") });
var coll = db.GetCollection<Weather>(collectionName);
var rnd = new Random();
await coll.InsertManyAsync(Enumerable.Range(0, 10000).Select(x => new Weather
{
    RegisteredAt = DateTime.Now.AddMinutes(rnd.Next(10000) * (rnd.NextDouble() > .5 ? -1 : 1)),
    Data = new Data { Sensor = $"sensor{x % 10:00}", Type = "temperature" },
    Temperature = rnd.Next(60) - 10
}));

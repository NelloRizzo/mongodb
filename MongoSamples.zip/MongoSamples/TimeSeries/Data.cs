﻿using MongoDB.Bson.Serialization.Attributes;
using nr.Describable;

namespace TimeSeries
{
    public class Data : JSONDescribable
    {
        [BsonElement("sensor")]
        public string? Sensor { get; set; }
        [BsonElement("type")]
        public string? Type { get; set; }
    }
}
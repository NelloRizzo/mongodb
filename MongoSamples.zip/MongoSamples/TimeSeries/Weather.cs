﻿using MongoDB.Bson.Serialization.Attributes;
using nr.Describable;

namespace TimeSeries
{
    public class Weather : JSONDescribable
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonElement("_id")]
        public string? Id { get; set; }
        [BsonElement("data")]
        public Data? Data { get; set; }
        [BsonElement("registration_time")]
        public DateTime RegisteredAt { get; set; }
        [BsonElement("temperature")]
        public int Temperature { get; set; }
    }
}
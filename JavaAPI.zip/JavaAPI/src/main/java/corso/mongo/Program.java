package corso.mongo;

import com.mongodb.client.MongoClients;
import org.bson.Document;

public class Program {
    public static void main(String[] args) {
        try (var mongo = MongoClients.create("mongodb://localhost:27017")) {
            var database = mongo.getDatabase("samples");
            var collection = database.getCollection("users");
            var query = Document.parse("{firstName: { $regex: /^[AP]/i } }");
            final var cursor = collection.find(query);
            cursor.forEach(System.out::println);
            cursor.forEach(d -> System.out.println(d.get("firstName", String.class)));
            cursor.map(d -> new User(d.getObjectId("_id").toString(), d.getString("firstName"),
                            d.getString("lastName"), d.getString("username"), d.getString("password")))
                    .forEach(System.out::println);
        }
    }
}

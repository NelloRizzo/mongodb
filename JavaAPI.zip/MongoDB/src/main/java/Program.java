import okhttp3.*;

import java.io.IOException;
import java.util.Optional;

class Program {
    public static void main(String[] args) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType,
                "{\"collection\":\"weather\"," +
                        "\"database\":\"corso\"," +
                        "\"dataSource\":\"Cluster0\"" +
                        "}");
        Request request = new Request.Builder()
                .url("https://eu-central-1.aws.data.mongodb-api.com/app/data-bwmjr/endpoint/data/v1/action/find")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Access-Control-Request-Headers", "*")
                .addHeader("api-key", "Gv21FcIWV79jzLjXf9AQFub7lbyxeksl1fAuEeSuijCTF3KLAnaVxPDpK4IBD4U1")
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.body() == null) {
                System.out.println("Corpo vuoto");
                return;
            }
            Optional.of(response.body()).ifPresentOrElse(s -> {
                try {
                    System.out.println(s.string());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }, () -> System.out.println("Nessuna risposta"));
        }
    }
}
